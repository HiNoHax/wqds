#!/usr/bin/env python
from wfuzz.wfuzz import main_filter

if __name__ == '__main__':
    main_filter()
